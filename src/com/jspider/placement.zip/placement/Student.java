package com.jspider.placement;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Comparator;

public class Student {
    int id ;
    String name;
    String add;

    public Student(int id, String name, String add) {
        this.id = id;
        this.name = name;
        this.add = add;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", add='" + add + '\'' +
                '}';
    }
}
class  CompAdd implements Comparator<Student>
{

    @Override
    public int compare(Student o1, Student o2) {
      //return   o1.add.length()-o2.add.length();
       return  (o1.add.compareTo(o2.add)) ;
       // return o1.id-o2.id;
    }
}
class Drive{
    public static void main(String[] args) {
        Student s1 = new Student(2, "savan", "delhi");
        Student s2 = new Student(1, "rahul", "bangalore");

        Student[] a = {s1, s2};
        Arrays.sort(a,new CompAdd());
       for (Student n :a)
       {
           System.out.println(n);
       }
    }
}
